-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 30-06-2016 a las 17:42:10
-- Versión del servidor: 5.1.36
-- Versión de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sales_umk`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `UsuarioID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Id de usuario',
  `NombreUsuario` varchar(100) NOT NULL COMMENT 'Nombre de Usuario',
  `Password` varchar(100) NOT NULL COMMENT 'Contraseña de Usuario',
  `Privilegios` int(11) NOT NULL COMMENT 'Privilegios de Usuarios',
  `FechaCreacion` date NOT NULL COMMENT 'Fecha de Creación de Usuario',
  PRIMARY KEY (`UsuarioID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`UsuarioID`, `NombreUsuario`, `Password`, `Privilegios`, `FechaCreacion`) VALUES
(1, 'admin', '123', 0, '2016-06-20'),
(2, 'Service', '123', 2, '2016-06-20'),
(3, 'Administrativo', '123', 1, '2016-06-20');
